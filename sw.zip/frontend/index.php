<?php declare(strict_types=1); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>San Bartolome</title>
    <link rel="manifest" href="manifest.webmanifest">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <link rel="stylesheet" href="frontend/style.css">
</head>
<body>
    <div id="auth-screen" class="screen auth-screen">
        <div class="auth-shell">
            <section class="card auth-panel">
                <div class="brand-pill">SB</div>
                <h1>San Bartolome</h1>
                <p class="subtitle">Sistema profesional de levantamiento y gestion de encuestadores para San Bartolome.</p>

                <div class="auth-switch">
                    <button id="switch-login" class="switch-pill active" type="button">Iniciar sesion</button>
                    <button id="switch-register" class="switch-pill" type="button">Postularme</button>
                </div>

                <form id="login-form" class="auth-form">
                    <label class="field-label" for="login-username">Usuario</label>
                    <input id="login-username" type="text" autocomplete="username" value="admin_general">

                    <label class="field-label" for="login-password">Clave</label>
                    <input id="login-password" type="password" autocomplete="current-password" placeholder="Ingresa tu clave">

                    <p id="login-error" class="error hidden"></p>
                    <button class="primary-button" type="submit">Entrar al sistema</button>
                </form>

                <form id="register-form" class="auth-form hidden" enctype="multipart/form-data">
                    <div class="form-grid">
                        <div>
                            <label class="field-label" for="reg-full-name">Nombres completos</label>
                            <input id="reg-full-name" name="full_name" type="text" required>
                        </div>
                        <div>
                            <label class="field-label" for="reg-document">Cedula</label>
                            <input id="reg-document" name="document_number" type="text" required>
                        </div>
                        <div>
                            <label class="field-label" for="reg-phone">Celular</label>
                            <input id="reg-phone" name="phone" type="text" required>
                        </div>
                        <div>
                            <label class="field-label" for="reg-email">Correo</label>
                            <input id="reg-email" name="email" type="email" required>
                        </div>
                        <div>
                            <label class="field-label" for="reg-parish">Parroquia</label>
                            <input id="reg-parish" name="parish" type="text" required>
                        </div>
                        <div>
                            <label class="field-label" for="reg-canton">Canton</label>
                            <input id="reg-canton" name="canton" type="text" required>
                        </div>
                    </div>

                    <label class="field-label" for="reg-address">Direccion</label>
                    <input id="reg-address" name="address" type="text" required>

                    <div class="form-grid">
                        <div>
                            <label class="field-label" for="reg-zone">Zona donde trabajaria</label>
                            <input id="reg-zone" name="requested_zone" type="text" required>
                        </div>
                        <div>
                            <label class="field-label" for="reg-username">Usuario deseado</label>
                            <input id="reg-username" name="username" type="text" required>
                        </div>
                    </div>

                    <label class="field-label" for="reg-experience">Experiencia previa</label>
                    <textarea id="reg-experience" name="experience" rows="3" required></textarea>

                    <div class="form-grid">
                        <div>
                            <label class="field-label" for="reg-password">Clave</label>
                            <input id="reg-password" name="password" type="password" required>
                        </div>
                        <div>
                            <label class="field-label" for="reg-password-confirm">Confirmar clave</label>
                            <input id="reg-password-confirm" name="password_confirm" type="password" required>
                        </div>
                    </div>

                    <div class="form-grid">
                        <div>
                            <label class="field-label" for="reg-profile-photo">Foto personal</label>
                            <input id="reg-profile-photo" name="profile_photo" type="file" accept=".jpg,.jpeg,.png,.pdf" required>
                        </div>
                        <div>
                            <label class="field-label" for="reg-id-document">Foto de cedula</label>
                            <input id="reg-id-document" name="id_document" type="file" accept=".jpg,.jpeg,.png,.pdf" required>
                        </div>
                    </div>

                    <label class="field-label" for="reg-support-document">Respaldo adicional (opcional)</label>
                    <input id="reg-support-document" name="support_document" type="file" accept=".jpg,.jpeg,.png,.pdf">

                    <p id="register-error" class="error hidden"></p>
                    <p id="register-success" class="success hidden"></p>
                    <button class="primary-button" type="submit">Enviar postulacion</button>
                </form>
            </section>
        </div>
    </div>

    <div id="status-screen" class="screen hidden">
        <div class="status-shell">
            <section class="card status-card">
                <h2 id="status-title">Estado de solicitud</h2>
                <p id="status-message" class="subtitle"></p>
                <div id="status-meta" class="status-meta"></div>
                <div class="inline-actions">
                    <button id="status-logout" class="secondary-button" type="button">Cerrar sesion</button>
                </div>
            </section>
        </div>
    </div>

    <div id="app-screen" class="screen hidden">
        <header class="topbar">
            <div>
                <div class="logo-tag">San Bartolome</div>
                <h2>Mapeo Social Integrado - San Bartolome</h2>
                <p class="subtitle-light">Levantamiento parroquial, postulaciones y aprobacion profesional de encuestadores</p>
            </div>
            <div class="top-actions">
                <span id="network-chip" class="chip chip-online hidden">Con conexion</span>
                <span id="offline-chip" class="chip chip-warning hidden">0 pendientes</span>
                <span id="user-badge" class="chip chip-dark">Usuario</span>
                <span id="role-badge" class="chip chip-dark">Rol</span>
                <button id="logout-button" class="secondary-button">Salir</button>
            </div>
        </header>

        <main class="layout">
            <nav class="tabs">
                <button id="tab-button-dashboard" class="tab active" data-tab="dashboard">Dashboard</button>
                <button id="tab-button-surveys" class="tab" data-tab="surveys">Encuestas</button>
                <button class="tab" data-tab="survey">Formulario</button>
                <button id="tab-button-profile" class="tab hidden" data-tab="profile">Mi perfil</button>
                <button id="tab-button-my-surveys" class="tab hidden" data-tab="my-surveys">Mis encuestas</button>
                <button id="tab-button-applications" class="tab" data-tab="applications">Postulaciones</button>
                <button id="tab-button-surveyors" class="tab" data-tab="surveyors">Encuestadores</button>
                <button id="tab-button-audit" class="tab" data-tab="audit">Auditoria</button>
                <button id="tab-button-offline" class="tab hidden" data-tab="offline">Cola Offline</button>
            </nav>

            <section id="tab-dashboard" class="tab-panel">
                <div class="panel-row">
                    <div class="card">
                        <label class="field-label" for="sector-filter">Sector en monitoreo</label>
                        <select id="sector-filter">
                            <option value="general">Todo San Bartolome</option>
                            <option value="centro">Centro Parroquial</option>
                            <option value="deleg">La Deleg</option>
                            <option value="sallac">Sallac</option>
                            <option value="pishio">Pishio</option>
                        </select>
                    </div>
                    <div id="network-card" class="card network-card hidden">
                        <div>
                            <h3>Estado de conectividad</h3>
                            <p>Referencia visual para levantamiento desde dispositivos de campo.</p>
                        </div>
                        <span id="network-card-status" class="helper-text">Con conexion a internet.</span>
                    </div>
                </div>

                <div class="kpi-grid">
                    <article class="card kpi-card">
                        <span class="eyebrow">Muestras levantadas</span>
                        <h3 id="kpi-total">0 / 300</h3>
                        <div class="progress"><div id="kpi-total-bar" class="progress-bar"></div></div>
                    </article>
                    <article class="card kpi-card">
                        <span class="eyebrow">Pobreza estructural estimada</span>
                        <h3 id="kpi-poverty">0%</h3>
                    </article>
                    <article class="card kpi-card">
                        <span class="eyebrow">Apertura a reapertura</span>
                        <h3 id="kpi-acceptance">0%</h3>
                    </article>
                    <article class="card kpi-card">
                        <span class="eyebrow">Clima politico predominante</span>
                        <h3 id="kpi-climate">Sin datos</h3>
                    </article>
                </div>

                <div class="dashboard-grid">
                    <article class="card">
                        <div class="section-title">
                            <h3>Mapa de encuestas georreferenciadas</h3>
                            <p>Ultimos puntos levantados por sector.</p>
                        </div>
                        <div id="map-canvas" class="map-canvas"></div>
                    </article>
                    <article class="card">
                        <div class="section-title">
                            <h3>Indicadores de contraste territorial</h3>
                            <p>Lectura social del levantamiento y del proceso de postulaciones.</p>
                        </div>
                        <div class="meter-list">
                            <div>
                                <div class="meter-head"><span>Riesgo de agua y saneamiento</span><strong id="metric-water">0%</strong></div>
                                <div class="progress"><div id="metric-water-bar" class="progress-bar alt-red"></div></div>
                            </div>
                            <div>
                                <div class="meter-head"><span>Brecha de alcantarillado</span><strong id="metric-sewer">0%</strong></div>
                                <div class="progress"><div id="metric-sewer-bar" class="progress-bar alt-amber"></div></div>
                            </div>
                            <div>
                                <div class="meter-head"><span>Presion por ingresos</span><strong id="metric-income">0%</strong></div>
                                <div class="progress"><div id="metric-income-bar" class="progress-bar alt-violet"></div></div>
                            </div>
                        </div>
                        <div class="application-kpis">
                            <div class="mini-kpi"><span>Pendientes</span><strong id="applications-pending">0</strong></div>
                            <div class="mini-kpi"><span>En revision</span><strong id="applications-review">0</strong></div>
                            <div class="mini-kpi"><span>Aprobadas</span><strong id="applications-approved">0</strong></div>
                            <div class="mini-kpi"><span>Rechazadas</span><strong id="applications-rejected">0</strong></div>
                        </div>
                    </article>
                </div>
            </section>

            <section id="tab-surveys" class="tab-panel hidden">
                <div class="section-title">
                    <h3>Encuestas levantadas</h3>
                    <p>Consulta, filtra y exporta las encuestas registradas.</p>
                </div>
                <div class="card filter-panel">
                    <div class="form-grid">
                        <div>
                            <label class="field-label" for="survey-filter-sector">Sector</label>
                            <select id="survey-filter-sector">
                                <option value="general">Todos</option>
                                <option value="centro">Centro Parroquial</option>
                                <option value="deleg">La Deleg</option>
                                <option value="sallac">Sallac</option>
                                <option value="pishio">Pishio</option>
                            </select>
                        </div>
                        <div>
                            <label class="field-label" for="survey-filter-surveyor">Encuestador</label>
                            <select id="survey-filter-surveyor">
                                <option value="">Todos</option>
                            </select>
                        </div>
                        <div>
                            <label class="field-label" for="survey-filter-date-from">Fecha desde</label>
                            <input id="survey-filter-date-from" type="date">
                        </div>
                        <div>
                            <label class="field-label" for="survey-filter-date-to">Fecha hasta</label>
                            <input id="survey-filter-date-to" type="date">
                        </div>
                        <div>
                            <label class="field-label" for="survey-filter-status">Estado</label>
                            <select id="survey-filter-status">
                                <option value="all">Todos</option>
                                <option value="sincronizada">Sincronizada</option>
                                <option value="revisada">Revisada</option>
                                <option value="observada">Observada</option>
                                <option value="Con GPS">Con GPS</option>
                                <option value="Sin GPS">Sin GPS</option>
                            </select>
                        </div>
                    </div>
                    <div class="inline-actions">
                        <button id="apply-survey-filters-button" class="secondary-button" type="button">Aplicar filtros</button>
                        <button id="export-surveys-button" class="primary-button" type="button">Exportar CSV</button>
                    </div>
                </div>
                <div id="surveys-list" class="stack-list"></div>
            </section>

            <section id="tab-survey" class="tab-panel hidden">
                <div id="surveyor-workspace" class="surveyor-stack hidden">
                    <article id="surveyor-notice" class="card notice-card hidden">
                        <strong id="surveyor-notice-title">Estado del levantamiento</strong>
                        <p id="surveyor-notice-text" class="helper-text">Listo para trabajar.</p>
                    </article>
                </div>

                <form id="survey-form" class="survey-form">
                    <div class="card">
                        <div class="section-title">
                            <h3>Identificacion y contexto</h3>
                            <p>Campos base para ubicar la encuesta y al equipo de campo.</p>
                        </div>
                        <div class="form-grid">
                            <div>
                                <label class="field-label" for="sector">Sector</label>
                                <select id="sector" name="sector" required>
                                    <option value="">Selecciona</option>
                                    <option value="centro">Centro Parroquial</option>
                                    <option value="deleg">La Deleg</option>
                                    <option value="sallac">Sallac</option>
                                    <option value="pishio">Pishio</option>
                                </select>
                            </div>
                            <div>
                                <label class="field-label" for="community">Comunidad o barrio</label>
                                <input id="community" name="community" type="text" required>
                            </div>
                            <div>
                                <label class="field-label" for="survey-date">Fecha y hora</label>
                                <input id="survey-date" name="survey_date" type="datetime-local" required>
                            </div>
                            <div id="surveyor-select-wrapper">
                                <label class="field-label" for="surveyor-id">Encuestador</label>
                                <select id="surveyor-id" name="surveyor_id"></select>
                            </div>
                            <div id="assigned-surveyor-card" class="hidden readonly-card">
                                <label class="field-label">Encuestador asignado</label>
                                <div id="assigned-surveyor-name" class="readonly-value">Sin asignar</div>
                                <div id="assigned-surveyor-zone" class="helper-text"></div>
                            </div>
                            <div>
                                <label class="field-label" for="respondent-gender">Genero</label>
                                <select id="respondent-gender" name="respondent_gender" required>
                                    <option value="">Selecciona</option>
                                    <option>Mujer</option>
                                    <option>Hombre</option>
                                    <option>Otro</option>
                                </select>
                            </div>
                            <div>
                                <label class="field-label" for="age-range">Rango de edad</label>
                                <select id="age-range" name="age_range" required>
                                    <option value="">Selecciona</option>
                                    <option>18-25</option>
                                    <option>26-35</option>
                                    <option>36-45</option>
                                    <option>46-60</option>
                                    <option>61 o mas</option>
                                </select>
                            </div>
                            <div>
                                <label class="field-label" for="education-level">Nivel educativo</label>
                                <select id="education-level" name="education_level">
                                    <option value="">Selecciona</option>
                                    <option>Primaria</option>
                                    <option>Secundaria</option>
                                    <option>Tecnico</option>
                                    <option>Universitario</option>
                                    <option>Ninguno</option>
                                </select>
                            </div>
                            <div>
                                <label class="field-label" for="occupation">Ocupacion principal</label>
                                <input id="occupation" name="occupation" type="text" required>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="section-title">
                            <h3>Problematicas y dinamica social</h3>
                            <p>Preguntas amplias para leer el clima territorial sin entrar de forma brusca al tema minero.</p>
                        </div>
                        <div class="form-stack">
                            <div>
                                <label class="field-label" for="primary-problem">Principal problematica actual</label>
                                <select id="primary-problem" name="primary_problem" required>
                                    <option value="">Selecciona</option>
                                    <option>Inseguridad</option>
                                    <option>Falta de empleo</option>
                                    <option>Agua y saneamiento</option>
                                    <option>Vias en mal estado</option>
                                    <option>Salud</option>
                                    <option>Migracion juvenil</option>
                                </select>
                            </div>
                            <div>
                                <label class="field-label" for="youth-path">A que se dedican los jovenes al terminar sus estudios</label>
                                <select id="youth-path" name="youth_path" required>
                                    <option value="">Selecciona</option>
                                    <option>Migracion por falta de oportunidades</option>
                                    <option>Agricultura o trabajo informal</option>
                                    <option>Continuan estudios superiores</option>
                                    <option>Empleo local eventual</option>
                                </select>
                            </div>
                            <fieldset>
                                <legend class="field-label">Limitaciones economicas frecuentes para mujeres</legend>
                                <div class="check-grid">
                                    <label><input type="checkbox" name="women_roles" value="Precios bajos por intermediarios"> Precios bajos por intermediarios</label>
                                    <label><input type="checkbox" name="women_roles" value="Sobrecarga de cuidados"> Sobrecarga de cuidados</label>
                                    <label><input type="checkbox" name="women_roles" value="Poco acceso a financiamiento"> Poco acceso a financiamiento</label>
                                    <label><input type="checkbox" name="women_roles" value="Mercados limitados"> Mercados limitados</label>
                                </div>
                            </fieldset>
                        </div>
                    </div>

                    <div class="card">
                        <div class="section-title">
                            <h3>Condiciones del hogar y validacion territorial</h3>
                            <p>Sirve para contrastar en campo informacion socioeconomica tipo INEC.</p>
                        </div>
                        <div class="form-grid">
                            <div>
                                <label class="field-label" for="water-source">Fuente principal de agua</label>
                                <select id="water-source" name="water_source" required>
                                    <option value="">Selecciona</option>
                                    <option>Red publica con tratamiento</option>
                                    <option>Vertiente comunal sin purificacion</option>
                                    <option>Rio o acequia</option>
                                    <option>Tanquero u otra compra</option>
                                </select>
                            </div>
                            <div>
                                <label class="field-label" for="has-sewer">Alcantarillado</label>
                                <select id="has-sewer" name="has_sewer" required>
                                    <option value="">Selecciona</option>
                                    <option>Si tiene</option>
                                    <option>No tiene</option>
                                </select>
                            </div>
                            <div>
                                <label class="field-label" for="has-internet">Conectividad a internet</label>
                                <select id="has-internet" name="has_internet">
                                    <option value="">Selecciona</option>
                                    <option>Si estable</option>
                                    <option>Intermitente</option>
                                    <option>No tiene</option>
                                </select>
                            </div>
                            <div>
                                <label class="field-label" for="road-status">Estado de vias</label>
                                <select id="road-status" name="road_status">
                                    <option value="">Selecciona</option>
                                    <option>Bueno</option>
                                    <option>Regular</option>
                                    <option>Malo</option>
                                </select>
                            </div>
                            <div>
                                <label class="field-label" for="household-income">Ingresos del hogar</label>
                                <select id="household-income" name="household_income">
                                    <option value="">Selecciona</option>
                                    <option>No cubre la canasta</option>
                                    <option>Cubre apenas</option>
                                    <option>Cubre con algo de holgura</option>
                                </select>
                            </div>
                            <div>
                                <label class="field-label" for="authority-trust">Confianza en autoridades</label>
                                <select id="authority-trust" name="authority_trust">
                                    <option value="">Selecciona</option>
                                    <option>Alta</option>
                                    <option>Media</option>
                                    <option>Baja</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="section-title">
                            <h3>Clima politico y percepcion territorial</h3>
                            <p>Bloque util para entender la postura comunitaria frente a proyectos externos.</p>
                        </div>
                        <div class="form-stack">
                            <div>
                                <label class="field-label" for="political-climate">Como se esta manejando la parte politica local</label>
                                <select id="political-climate" name="political_climate" required>
                                    <option value="">Selecciona</option>
                                    <option>Desconfianza institucional</option>
                                    <option>Division comunitaria</option>
                                    <option>Estabilidad relativa</option>
                                    <option>Conflicto abierto entre actores</option>
                                </select>
                            </div>
                            <div>
                                <label class="field-label" for="social-priority">Prioridad del territorio si aparece una gran inversion externa</label>
                                <select id="social-priority" name="social_priority" required>
                                    <option value="">Selecciona</option>
                                    <option>Proteger agua y paramos</option>
                                    <option>Generar empleo rapido</option>
                                    <option>Mejorar vias y servicios</option>
                                    <option>Fortalecer produccion local</option>
                                </select>
                            </div>
                            <div>
                                <label class="field-label" for="investment-acceptance">Aceptacion frente a proyectos externos que prometen empleo</label>
                                <select id="investment-acceptance" name="investment_acceptance" required>
                                    <option value="">Selecciona</option>
                                    <option>Rechazo preventivo</option>
                                    <option>Aceptacion condicionada</option>
                                    <option>Aceptacion amplia</option>
                                </select>
                            </div>
                            <div>
                                <label class="field-label" for="mine-reopening-perception">Como creen que beneficiaria la reapertura de la mina Silver 1</label>
                                <select id="mine-reopening-perception" name="mine_reopening_perception" required>
                                    <option value="">Selecciona</option>
                                    <option>Beneficiaria mucho</option>
                                    <option>Beneficiaria algo</option>
                                    <option>Beneficio dudoso</option>
                                    <option>No beneficiaria</option>
                                </select>
                            </div>
                            <fieldset>
                                <legend class="field-label">Beneficios esperados</legend>
                                <div class="check-grid">
                                    <label><input type="checkbox" name="mine_benefits" value="Empleo juvenil"> Empleo juvenil</label>
                                    <label><input type="checkbox" name="mine_benefits" value="Movimiento comercial"> Movimiento comercial</label>
                                    <label><input type="checkbox" name="mine_benefits" value="Obras comunitarias"> Obras comunitarias</label>
                                    <label><input type="checkbox" name="mine_benefits" value="Ninguno claro"> Ninguno claro</label>
                                </div>
                            </fieldset>
                            <fieldset>
                                <legend class="field-label">Riesgos mas temidos</legend>
                                <div class="check-grid">
                                    <label><input type="checkbox" name="mine_risks" value="Contaminacion del agua"> Contaminacion del agua</label>
                                    <label><input type="checkbox" name="mine_risks" value="Danos al suelo"> Danos al suelo</label>
                                    <label><input type="checkbox" name="mine_risks" value="Conflicto social"> Conflicto social</label>
                                    <label><input type="checkbox" name="mine_risks" value="Poca transparencia"> Poca transparencia</label>
                                </div>
                            </fieldset>
                            <div>
                                <label class="field-label" for="comments">Observaciones adicionales</label>
                                <textarea id="comments" name="comments" rows="4"></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="section-title">
                            <h3>Ubicacion</h3>
                            <p>Puedes capturar GPS del dispositivo o ingresarlo manualmente si hace falta.</p>
                        </div>
                        <div class="form-grid">
                            <div>
                                <label class="field-label" for="latitude">Latitud</label>
                                <input id="latitude" name="latitude" type="number" step="0.0000001">
                            </div>
                            <div>
                                <label class="field-label" for="longitude">Longitud</label>
                                <input id="longitude" name="longitude" type="number" step="0.0000001">
                            </div>
                        </div>
                        <div class="inline-actions">
                            <button id="capture-gps-button" class="secondary-button" type="button">Capturar GPS</button>
                            <span id="gps-status" class="helper-text">Aun no se ha capturado una coordenada.</span>
                        </div>
                        <div class="location-map-shell">
                            <div id="survey-location-map" class="survey-location-map"></div>
                            <p id="map-status" class="helper-text">
                                Usa el boton de GPS para ubicarte. Tambien puedes tocar el mapa para ajustar el punto manualmente.
                            </p>
                        </div>
                    </div>

                    <div class="form-footer">
                        <span id="save-status" class="helper-text">Listo para guardar.</span>
                        <button id="cancel-edit-button" class="secondary-button hidden" type="button">Cancelar edicion</button>
                        <button class="primary-button" type="submit">Guardar encuesta</button>
                    </div>
                </form>
                <div id="offline-summary-card" class="card hidden">
                    <div class="section-title">
                        <h3>Sincronizacion pendiente</h3>
                        <p>Este aviso solo aparece cuando el dispositivo guarda encuestas sin internet.</p>
                    </div>
                    <div class="inline-actions">
                        <strong id="offline-summary-text">0 encuestas pendientes</strong>
                        <button id="show-offline-details-button" class="secondary-button" type="button">Ver detalle</button>
                    </div>
                </div>
            </section>

            <section id="tab-profile" class="tab-panel hidden">
                <article class="card surveyor-profile-card">
                    <div class="section-title">
                        <h3>Mi perfil</h3>
                        <p>Resumen operativo de la cuenta aprobada para levantar encuestas.</p>
                    </div>
                    <div class="surveyor-profile-grid">
                        <div class="profile-identity">
                            <strong id="profile-view-name">Sin asignar</strong>
                            <span id="profile-view-username" class="helper-text"></span>
                        </div>
                        <div class="profile-kv">
                            <span>Zona asignada</span>
                            <strong id="profile-view-zone">Sin zona</strong>
                        </div>
                        <div class="profile-kv">
                            <span>Estado</span>
                            <strong id="profile-view-status">Sin estado</strong>
                        </div>
                        <div class="profile-kv">
                            <span>Conexion</span>
                            <strong id="profile-view-connection">Sin definir</strong>
                        </div>
                        <div class="profile-kv">
                            <span>Borrador local</span>
                            <strong id="profile-view-draft">No</strong>
                        </div>
                    </div>
                    <div class="application-kpis surveyor-kpis">
                        <div class="mini-kpi"><span>Total propias</span><strong id="profile-total-count">0</strong></div>
                        <div class="mini-kpi"><span>Sincronizadas</span><strong id="profile-sync-count">0</strong></div>
                        <div class="mini-kpi"><span>Revisadas</span><strong id="profile-reviewed-count">0</strong></div>
                        <div class="mini-kpi"><span>Observadas</span><strong id="profile-observed-count">0</strong></div>
                    </div>
                    <div class="inline-actions">
                        <button id="profile-continue-draft-button" class="secondary-button hidden" type="button">Continuar borrador</button>
                    </div>
                </article>
            </section>

            <section id="tab-my-surveys" class="tab-panel hidden">
                <div class="section-title">
                    <h3>Mis encuestas</h3>
                    <p>Consulta y, si hace falta, vuelve a editar solo tus propias encuestas.</p>
                </div>
                <div id="my-surveys-summary" class="application-kpis surveyor-kpis"></div>
                <div id="my-surveys-list" class="stack-list"></div>
            </section>

            <section id="tab-applications" class="tab-panel hidden">
                <div class="section-title">
                    <h3>Postulaciones de encuestadores</h3>
                    <p>Revisa documentos, observa detalles y aprueba o rechaza cada solicitud.</p>
                </div>
                <div class="inline-actions section-actions">
                    <button id="export-applications-button" class="primary-button" type="button">Exportar CSV</button>
                </div>
                <div class="subtabs" id="application-subtabs">
                    <button class="subtab active" data-status="all" type="button">Todas <span id="count-all">0</span></button>
                    <button class="subtab" data-status="pending" type="button">Pendientes <span id="count-pending">0</span></button>
                    <button class="subtab" data-status="in_review" type="button">En revision <span id="count-in_review">0</span></button>
                    <button class="subtab" data-status="approved" type="button">Aprobadas <span id="count-approved">0</span></button>
                    <button class="subtab" data-status="rejected" type="button">Rechazadas <span id="count-rejected">0</span></button>
                </div>
                <div id="applications-list" class="stack-list"></div>
            </section>

            <section id="tab-surveyors" class="tab-panel hidden">
                <div class="section-title">
                    <h3>Encuestadores activos</h3>
                    <p>Control de estado operativo, zona asignada y reseteo de clave.</p>
                </div>
                <div id="surveyors-list" class="stack-list"></div>
            </section>

            <section id="tab-audit" class="tab-panel hidden">
                <div class="section-title">
                    <h3>Auditoria de movimientos</h3>
                    <p>Consulta las acciones administrativas y operativas registradas por el sistema.</p>
                </div>
                <div class="card filter-panel">
                    <div class="form-grid">
                        <div>
                            <label class="field-label" for="audit-filter-action">Accion</label>
                            <select id="audit-filter-action">
                                <option value="all">Todas</option>
                                <option value="login">Login</option>
                                <option value="register_application">Registro postulacion</option>
                                <option value="review_application">Revision postulacion</option>
                                <option value="update_surveyor_status">Estado encuestador</option>
                                <option value="update_surveyor_profile">Zona encuestador</option>
                                <option value="reset_password">Reset clave</option>
                                <option value="save_survey">Guardar encuesta</option>
                            </select>
                        </div>
                        <div>
                            <label class="field-label" for="audit-filter-date-from">Fecha desde</label>
                            <input id="audit-filter-date-from" type="date">
                        </div>
                        <div>
                            <label class="field-label" for="audit-filter-date-to">Fecha hasta</label>
                            <input id="audit-filter-date-to" type="date">
                        </div>
                    </div>
                    <div class="inline-actions">
                        <button id="apply-audit-filters-button" class="secondary-button" type="button">Aplicar filtros</button>
                        <button id="export-audit-button" class="primary-button" type="button">Exportar CSV</button>
                    </div>
                </div>
                <div id="audit-list" class="stack-list"></div>
            </section>

            <section id="tab-offline" class="tab-panel hidden">
                <div class="offline-grid">
                    <article class="card">
                        <div class="section-title">
                            <h3>Cola offline</h3>
                            <p>Encuestas guardadas localmente mientras el equipo esta sin internet.</p>
                        </div>
                        <div class="big-counter" id="offline-count">0 formularios</div>
                        <div class="inline-actions">
                            <button id="sync-button" class="success-button" type="button">Forzar sincronizacion</button>
                            <span id="sync-status" class="helper-text">Sin pendientes por ahora.</span>
                        </div>
                    </article>
                    <article class="card">
                        <div class="section-title">
                            <h3>Registros pendientes</h3>
                            <p>Se conservan en el navegador del dispositivo.</p>
                        </div>
                        <div id="offline-list" class="offline-list">
                            <p class="empty-state">No hay encuestas pendientes.</p>
                        </div>
                    </article>
                </div>
            </section>
        </main>
    </div>

    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="frontend/app.js"></script>
</body>
</html>
